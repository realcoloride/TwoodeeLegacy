package org.coloride.twoodee.World;

public enum LightingType {
    FULL_BRIGHT,
    MODERN_LIGHTING, // todo - Box2d lighting
    SPIKE;
}
