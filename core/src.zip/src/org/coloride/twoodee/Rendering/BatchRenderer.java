package org.coloride.twoodee.Rendering;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import org.coloride.twoodee.UI.DebugUI;
import org.coloride.twoodee.World.WorldRenderer;

public class BatchRenderer {
    public static SpriteBatch tilesBatch = new SpriteBatch();
    public static SpriteBatch uiBatch = new SpriteBatch();
    public static SpriteBatch debugUiBatch = new SpriteBatch();

    public static void process(float delta) {
        WorldRenderer.process(delta);

        DebugUI.process(delta);
    }

    public static void draw(float delta) {
        WorldRenderer.draw(delta);

        // Ui batching
        DebugUI.draw(delta);
    }
}
