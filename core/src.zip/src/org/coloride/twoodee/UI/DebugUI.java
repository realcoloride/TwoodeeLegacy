package org.coloride.twoodee.UI;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.physics.box2d.World;
import org.coloride.twoodee.Rendering.BatchRenderer;
import org.coloride.twoodee.Rendering.Camera;
import org.coloride.twoodee.World.*;

import static org.coloride.twoodee.World.WorldRenderer.getRegionFromTexture;
import static org.coloride.twoodee.World.WorldRenderer.getTileTexture;

public class DebugUI {
    private static BitmapFont debugFont = new BitmapFont();
    private static GlyphLayout debugGlyphLayout = new GlyphLayout();
    private static ShapeRenderer shapeRenderer = new ShapeRenderer();
    private static ShapeRenderer terrainShapeRenderer = new ShapeRenderer();
    private static SpriteBatch debugUiBatch = BatchRenderer.debugUiBatch;

    public static int workload = 0;

    public static void process(float delta) {

    }

    public static void draw(float delta) {
        Chunk chunk = WorldRenderer.getChunkFromSpacePosition(Camera.getCursorPositionInSpace());
        WorldTile tile = WorldRenderer.getTileFromSpacePosition(Camera.getCursorPositionInSpace());

        String debugText = String.join("",
                "Mouse coordinates: " + Gdx.input.getX() + "," + Gdx.input.getY() + "\n",
                "Hovered chunk: " + ((chunk != null) ? (chunk.getChunkPosition().toString()+" - Biome: "+ chunk.getChunkBiome().getBiomeName()) : "No chunk") + "\n",
                "Hovered tile: " + ((tile != null) ? ("Tile: " + tile.getTilePosition().toString() + " - Id: " + tile.getTileId() + " - Orientation: " + tile.getTileOrientation() + " - Light Intensity: " + tile.getlightIntensity() + " (I:" + TileType.getTileTypeById(tile.getTileId()).getLightInfluence() + ")")  : "No tile") + "\n"
                );

        if (chunk != null) {
            terrainShapeRenderer.setProjectionMatrix(Camera.camera.combined);
            terrainShapeRenderer.begin(ShapeRenderer.ShapeType.Line);
            terrainShapeRenderer.setColor(125,0,125,.75f);
            terrainShapeRenderer.rect(chunk.getChunkPosition().x*Chunk.chunkSize.x,chunk.getChunkPosition().y*Chunk.chunkSize.y,Chunk.chunkSize.x,Chunk.chunkSize.y);
            terrainShapeRenderer.end();
        }
        if (tile != null) {
            terrainShapeRenderer.setProjectionMatrix(Camera.camera.combined);
            terrainShapeRenderer.begin(ShapeRenderer.ShapeType.Line);
            terrainShapeRenderer.setColor(0,0,1,0);
            terrainShapeRenderer.rect(
                    chunk.getChunkPosition().x * Chunk.chunkSize.x + tile.getTilePosition().x * WorldTile.tileSize.x,
                    chunk.getChunkPosition().y * Chunk.chunkSize.y + tile.getTilePosition().y * WorldTile.tileSize.y,
                    WorldTile.tileSize.x,
                    WorldTile.tileSize.y
            );
            terrainShapeRenderer.end();
        }

        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(0,0,0,.75f);
        shapeRenderer.rect(Gdx.input.getX(), Gdx.graphics.getHeight() - Gdx.input.getY() - debugGlyphLayout.height-10f, debugGlyphLayout.width + 5, debugGlyphLayout.height + 15f);
        shapeRenderer.setColor(1,1,1,1);
        shapeRenderer.rect(Gdx.input.getX()+14, Gdx.graphics.getHeight() - Gdx.input.getY() - 15,18,18);
        shapeRenderer.end();

        debugUiBatch.begin();

        if (tile != null) {
            TextureRegion[][] textureRegion = getRegionFromTexture(getTileTexture(tile.getTileId()));
            Sprite sprite = new Sprite(AutoTiling.getTextureRegionFromWorldTile(textureRegion, tile));
            sprite.setPosition(Gdx.input.getX()+15, Gdx.graphics.getHeight() - Gdx.input.getY() - 14);
            sprite.draw(debugUiBatch);
        }

        debugGlyphLayout.setText(debugFont, debugText);
        float w = debugGlyphLayout.width;
        debugFont.draw(debugUiBatch, debugText, Gdx.input.getX()+1.5f, Gdx.graphics.getHeight() - Gdx.input.getY() - 20-2.5f);
        String fpsText = "Tiles workload: " + workload + " - FPS: " + Gdx.graphics.getFramesPerSecond();

        debugFont.draw(debugUiBatch, fpsText, Gdx.input.getX()+w-1.5f-new GlyphLayout(debugFont, fpsText).width, Gdx.graphics.getHeight() - Gdx.input.getY() - 2.5f);

        debugUiBatch.end();

    }
}
