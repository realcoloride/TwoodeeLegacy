package org.coloride.twoodee.World;

import com.badlogic.gdx.math.Vector2;
import jdk.nashorn.internal.runtime.Debug;
import org.coloride.twoodee.World.Biomes.DebugBiome;

import java.util.Map;
import java.util.Vector;

public class WorldGenerator {
    public static void generateWorld(MapInformation.MapSize mapSize) {
        for (int cx = 0; cx < MapInformation.mapSizes.get(mapSize).x; cx++) {
            for (int cy = 0; cy < MapInformation.mapSizes.get(mapSize).y; cy++) {
                // For each chunk
                Vector2 chunkPosition = new Vector2(cx,cy);

                Chunk chunk = new Chunk(chunkPosition, new DebugBiome());
                chunk.generate();
                WorldRenderer.loadedChunks.put(chunkPosition, chunk);
            }
        }
    };
}
