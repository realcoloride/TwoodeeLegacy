package org.coloride.twoodee.World;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.collision.BoundingBox;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.ScreenUtils;
import jdk.nashorn.internal.runtime.Debug;
import org.coloride.twoodee.Rendering.BatchRenderer;
import org.coloride.twoodee.Rendering.Camera;
import org.coloride.twoodee.UI.DebugUI;
import org.coloride.twoodee.Utilities.ColorUtilities;
import org.coloride.twoodee.Utilities.MathUtilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;

import static org.coloride.twoodee.Rendering.BatchRenderer.tilesBatch;
import static org.coloride.twoodee.Rendering.BatchRenderer.uiBatch;

public class WorldRenderer extends Thread {
    public static HashMap<Integer, Texture> tilesTextures = new HashMap<>();

    public static HashMap<Vector2, Chunk> loadedChunks = new HashMap<>();
    public static ArrayList<Chunk> renderedChunksBuffer = new ArrayList<>();

    public static ShapeRenderer shapeRenderer = new ShapeRenderer();

    public void run() {
        try {

        } catch (Exception e) {

        }
    }
    public static void loadTiles() {
        for (TileType tileType : TileType.values()) {
            int tileId = tileType.getTileId();
            String texturePath = "img/tiles/tile_" + tileId + ".png";

            tilesTextures.put(tileId, new Texture(Gdx.files.internal(texturePath)));
        }
    }

    // Tile textures
    public static Texture getTileTexture(int tileId) { return tilesTextures.get(tileId); }
    public static TextureRegion[][] getRegionFromTexture(Texture texture) { return TextureRegion.split(texture, (int)WorldTile.tileSize.x, (int)WorldTile.tileSize.y); }

    public static void drawSky() {
        Color skyColor = ColorUtilities.Conversion.RGBtoraw(145,222,255,255);
        ScreenUtils.clear(skyColor);
    }

    public static Chunk getChunkFromSpacePosition(Vector2 spacePosition) {
        // todo: use a class to store the loaded chunks
        for (Chunk chunk : loadedChunks.values()) {
            Vector2 chunkPosition = chunk.getChunkPosition();

            BoundingBox chunkBounds = MathUtilities.Conversion.boundingBox2dTo3d(
                    chunkPosition.x * Chunk.chunkSize.x,
                    chunkPosition.y * Chunk.chunkSize.y,
                    chunkPosition.x * Chunk.chunkSize.x + Chunk.chunkSize.x,
                    chunkPosition.y * Chunk.chunkSize.y + Chunk.chunkSize.y
            );

            boolean isInChunk = (chunkBounds.contains(MathUtilities.Conversion.vector2dTo3d(spacePosition)));
            if (isInChunk) { // ignore if null
                return chunk;
            }
        }
        return null;
    }
    public static WorldTile getTileFromChunkSpacePosition(Chunk chunk, Vector2 spacePosition) {
        if (chunk != null) {
            for (int x = 0; x < Chunk.chunkSize.x / WorldTile.tileSize.x; x++) {
                for (int y = 0; y < Chunk.chunkSize.y / WorldTile.tileSize.y; y++) {
                    BoundingBox tileBounds = MathUtilities.Conversion.boundingBox2dTo3d(
                            chunk.getChunkPosition().x * Chunk.chunkSize.x + x * WorldTile.tileSize.x,
                            chunk.getChunkPosition().y * Chunk.chunkSize.y + y * WorldTile.tileSize.y,
                            chunk.getChunkPosition().x * Chunk.chunkSize.x + x * WorldTile.tileSize.x + WorldTile.tileSize.x,
                            chunk.getChunkPosition().y * Chunk.chunkSize.y + y * WorldTile.tileSize.y + WorldTile.tileSize.y
                    );

                    boolean isInChunk = (tileBounds.contains(MathUtilities.Conversion.vector2dTo3d(spacePosition)));
                    if (isInChunk) {
                        return chunk.getTileFromChunk(new Vector2(x,y));
                    }
                }
            }
        }
        return null;
    }
    public static WorldTile getTileFromSpacePosition(Vector2 spacePosition) {
        Chunk chunk = getChunkFromSpacePosition(spacePosition);
        return getTileFromChunkSpacePosition(chunk, spacePosition);
    }
    private static Color getTileColorFromLight(WorldTile tile) {
        Color color = new Color();

        Integer lightIntensity = (tile.getlightIntensity() != null) ? tile.getlightIntensity() : 0;

        color.r = (float) lightIntensity * 1 / 16;
        color.g = (float) lightIntensity * 1 / 16;
        color.b = (float) lightIntensity * 1 / 16;
        color.a = (tile.getlightIntensity() != null ? 1 : 0.5f);

        return color;
    }

    public static void process(float delta) {
        if (TileLighting.chunkRefreshBuffer.size() > 0) {
            Thread drawThread = new TileLighting();
            drawThread.run();
        }
    }
    public static void draw(float delta) {
        // Draw Sky
        drawSky();

        // Draw from Camera
        tilesBatch.setProjectionMatrix(Camera.camera.combined);
        Camera.draw(delta);

        // Draw terrain
        tilesBatch.begin();

        // Chunk rendering
        for (Chunk chunk : loadedChunks.values()) {
            Vector2 chunkPosition = chunk.getChunkPosition();
            BoundingBox chunkBounds = MathUtilities.Conversion.boundingBox2dTo3d(
                    chunkPosition.x * Chunk.chunkSize.x,
                    chunkPosition.y * Chunk.chunkSize.y,
                    chunkPosition.x * Chunk.chunkSize.x + Chunk.chunkSize.x,
                    chunkPosition.y * Chunk.chunkSize.y + Chunk.chunkSize.y
            );

            boolean chunkVisible = Camera.camera.frustum.boundsInFrustum(chunkBounds);

            if (chunkVisible) {
                TileLighting.addTileToRefreshLightBuffer(chunk);

                HashMap<Vector2, WorldTile> chunkTiles = chunk.getChunkTiles();

                for (int x = 0; x < Chunk.chunkSize.x / WorldTile.tileSize.x; x++) {
                    for (int y = 0; y < Chunk.chunkSize.y / WorldTile.tileSize.y; y++) {
                        Vector2 tilePosition = new Vector2(x, y);
                        Vector2 tileSpacePosition = new Vector2(
                                chunk.getChunkPosition().x * Chunk.chunkSize.x + x * WorldTile.tileSize.x,
                                chunk.getChunkPosition().y * Chunk.chunkSize.y + y * WorldTile.tileSize.y);

                        BoundingBox blockBounds = MathUtilities.Conversion.boundingBox2dTo3d(
                                tileSpacePosition.x,
                                tileSpacePosition.y,
                                tileSpacePosition.x + WorldTile.tileSize.x,
                                tileSpacePosition.y + WorldTile.tileSize.y
                        );

                        // 256 + x * size
                        boolean blockVisible = Camera.camera.frustum.boundsInFrustum(blockBounds);

                        if (blockVisible) {
                            WorldTile tile = chunkTiles.get(tilePosition);
                            AutoTiling.processAutoTile(tile);

                            TextureRegion[][] textureRegion = getRegionFromTexture(getTileTexture(tile.getTileId()));
                            if (tile.getTileId() != 0) { // AIR
                                Sprite sprite = new Sprite(AutoTiling.getTextureRegionFromWorldTile(textureRegion, tile));
                                sprite.setColor(getTileColorFromLight(tile));
                                sprite.setPosition(tileSpacePosition.x, tileSpacePosition.y);
                                sprite.draw(tilesBatch);
                            }
                        }
                    }
                }
            }
        }

        tilesBatch.end();
    }
}
