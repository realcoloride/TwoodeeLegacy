package org.coloride.twoodee.World;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import org.coloride.twoodee.Utilities.MathUtilities;

public class WorldTile {

    public static Vector2 tileSize = new Vector2(16, 16);

    private int tileId;
    private Chunk chunk;
    private Vector2 tilePosition;
    public Integer lightIntensity = null; // Needs rendering
    public int tileOrientation;
    public boolean needsTileOrientationRefreshing = true;
    public boolean overrideTileOrientation = false;

    public boolean hasTileBack = false;
    public boolean hasTileFront = true;

    public WorldTile(int tileId, Chunk chunk, Vector2 tilePosition, boolean hasTileFront, boolean hasTileBack) { // todo: TileFlags class
        // Tile information
        this.tileId = tileId;

        // Tile environment data
        this.hasTileFront = hasTileFront;
        this.hasTileBack = hasTileBack;

        // Tile position
        this.chunk = chunk;
        this.tilePosition = tilePosition;
    }

    public static NeighbourTile getBlockNeighbourTile(WorldTile tile, Vector2 neighbourPosition) {
        NeighbourTile neighbourTile = null;
        Vector2 targetPosition = tile.getTilePosition();
        Vector2 adjustedNeighbourPosition = targetPosition.add(neighbourPosition);
        Chunk tileChunk = tile.getChunk();

        // Not in same chunk
        boolean isNeighbourPositionLeft  = (adjustedNeighbourPosition.x < 0);                 // <-|
        boolean isNeighbourPositionRight = (adjustedNeighbourPosition.x > Chunk.chunkSize.x); // |->
        boolean isNeighbourPositionTop   = (adjustedNeighbourPosition.y > Chunk.chunkSize.y);                 //
        boolean isNeighbourPositionBelow = (adjustedNeighbourPosition.y < 0); //

        if (
                isNeighbourPositionLeft  ||
                isNeighbourPositionRight ||
                isNeighbourPositionTop   ||
                isNeighbourPositionBelow
        ) {
            Vector2 leftNeighbourChunkPosition  = tileChunk.getChunkPosition().add(new Vector2(-1,0));
            Vector2 rightNeighbourChunkPosition = tileChunk.getChunkPosition().add(new Vector2(1,0));
            Vector2 topNeighbourChunkPosition   = tileChunk.getChunkPosition().add(new Vector2(0,1));
            Vector2 belowNeighbourChunkPosition = tileChunk.getChunkPosition().add(new Vector2(0,-1));

            Chunk targetChunk = null;

            // todo: use a class to store the loaded tiles
            targetChunk = WorldRenderer.loadedChunks.containsKey(leftNeighbourChunkPosition) ? WorldRenderer.loadedChunks.get(leftNeighbourChunkPosition) : null;
            targetChunk = WorldRenderer.loadedChunks.containsKey(rightNeighbourChunkPosition) ? WorldRenderer.loadedChunks.get(rightNeighbourChunkPosition) : null;
            targetChunk = WorldRenderer.loadedChunks.containsKey(topNeighbourChunkPosition) ? WorldRenderer.loadedChunks.get(topNeighbourChunkPosition) : null;
            targetChunk = WorldRenderer.loadedChunks.containsKey(belowNeighbourChunkPosition) ? WorldRenderer.loadedChunks.get(belowNeighbourChunkPosition) : null;

            if (targetChunk != null) {
                Vector2 flippedPosition = new Vector2();

                // flip position from chunk + target chunk + flipped position (depending on chunk direction)
                flippedPosition = isNeighbourPositionLeft ? new Vector2(Chunk.chunkSize.x + adjustedNeighbourPosition.x, adjustedNeighbourPosition.y) : flippedPosition;
                flippedPosition = isNeighbourPositionRight ? new Vector2(Chunk.chunkSize.x - adjustedNeighbourPosition.x, adjustedNeighbourPosition.y) : flippedPosition;
                flippedPosition = isNeighbourPositionTop ? new Vector2(adjustedNeighbourPosition.x, Chunk.chunkSize.y - adjustedNeighbourPosition.y) : flippedPosition;
                flippedPosition = isNeighbourPositionBelow ? new Vector2(adjustedNeighbourPosition.x, Chunk.chunkSize.y + adjustedNeighbourPosition.y) : flippedPosition;

                // return the tile if it exists or else it returns null
                return (targetChunk.getTileFromChunk(flippedPosition) != null) ? new NeighbourTile(targetChunk, targetChunk.getTileFromChunk(flippedPosition)) : new NeighbourTile(null, null);
            } else { return null; }
        }

        // In same chunk
        neighbourTile = new NeighbourTile(tileChunk, tileChunk.getTileFromChunk(adjustedNeighbourPosition));

        return neighbourTile;
    }

    public int getTileId() {return tileId;}
    public Chunk getChunk() {return chunk;}
    public Vector2 getTilePosition() {return tilePosition;}
    public Integer getlightIntensity() {return lightIntensity;}
    public int getTileOrientation() {return tileOrientation;}
    public boolean needsTileOrientationRefreshing() {return needsTileOrientationRefreshing;}
    public boolean hasTileFront() {return hasTileFront;}
    public boolean hasTileBack() {return hasTileBack;}
}
