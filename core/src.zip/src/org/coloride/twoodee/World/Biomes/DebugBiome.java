package org.coloride.twoodee.World.Biomes;

import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import org.coloride.twoodee.World.*;

import java.util.HashMap;

public class DebugBiome extends Biome {
    String biomeName = "DebugBiome";
    @Override
    public void generateTiles(Chunk chunk) {
        for (int y = 0; y < Chunk.chunkSize.y; y++) {
            for (int x = 0; x < Chunk.chunkSize.x; x++) {
                Vector2 tilePosition = new Vector2(x, y);
                WorldTile tile = new WorldTile(0, chunk, tilePosition, true, false);

                if (MathUtils.random(1,2) == 1) {
                    tile = new WorldTile(-1, chunk, tilePosition, true, false);
                }
                if (MathUtils.random(1,10) == 8) {
                    tile = new WorldTile(-2, chunk, tilePosition, true, false);
                }

                chunk.getChunkTiles().put(tilePosition, tile);
            }
        }
        //super.generateTiles(chunk);
    }
    @Override
    public String getBiomeName() {return biomeName;}
}
