package org.coloride.twoodee.World;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;

import java.util.HashMap;

public class AutoTiling {
    public static int northOrientation = 1;
    public static int eastOrientation = 2;
    public static int southOrientation = 4;
    public static int westOrientation = 8;

    public static TextureRegion getTextureRegionFromCoordinates(TextureRegion[][] textureRegion, int x, int y) {
        return textureRegion[x][y];
    }
    public static TextureRegion getTextureRegionFromCoordinates(TextureRegion[][] textureRegion, Vector2 coordinates) {
        return textureRegion[(int)coordinates.x][(int)coordinates.y];
    }
    public static TextureRegion getTextureRegionFromWorldTile(TextureRegion[][] textureRegion, WorldTile tile) {
        return getTextureRegionFromCoordinates(
                textureRegion,
                tile.hasTileFront() ? 0 : 1, tile.getTileOrientation()
        );
    }

    public static boolean areTilesTheSameId(WorldTile tile, NeighbourTile neighbourTile) {
        if (neighbourTile.getTile() != null) {
            return tile.getTileId() == neighbourTile.getTile().getTileId();
        }
        return false;
    }

    public static void processAutoTile(WorldTile tile) {
        if (tile.needsTileOrientationRefreshing()) {

            NeighbourTile neighbourNorthTile = WorldTile.getBlockNeighbourTile(tile, new Vector2(0, 1));
            NeighbourTile neighbourEastTile  = WorldTile.getBlockNeighbourTile(tile, new Vector2(-1,0));
            NeighbourTile neighbourSouthTile = WorldTile.getBlockNeighbourTile(tile, new Vector2(0,-1));
            NeighbourTile neighbourWestTile  = WorldTile.getBlockNeighbourTile(tile, new Vector2(1,0));

            int orientation = 0;

            orientation += areTilesTheSameId(tile, neighbourNorthTile) ? northOrientation : 0;
            orientation += areTilesTheSameId(tile, neighbourEastTile) ? eastOrientation : 0;
            orientation += areTilesTheSameId(tile, neighbourSouthTile) ? southOrientation : 0;
            orientation += areTilesTheSameId(tile, neighbourWestTile) ? westOrientation : 0;

            tile.tileOrientation = orientation;
        }
    }
}

