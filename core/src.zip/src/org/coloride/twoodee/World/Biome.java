package org.coloride.twoodee.World;

import com.badlogic.gdx.math.Vector2;

import java.util.HashMap;

public class Biome {
    String biomeName = "BaseBiome";

    public void generateTiles(Chunk chunk) {

    }

    public String getBiomeName() {return biomeName;}
}
