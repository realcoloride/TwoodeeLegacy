package org.coloride.twoodee.Logic;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Batch;
import org.coloride.twoodee.Rendering.BatchRenderer;
import org.coloride.twoodee.Rendering.Camera;
import org.coloride.twoodee.Utilities.TimeUtilities;
import org.coloride.twoodee.World.MapInformation;
import org.coloride.twoodee.World.WorldGenerator;
import org.coloride.twoodee.World.WorldRenderer;

public class GameLogic {
    public static void onLoad() {
        WorldGenerator.generateWorld(MapInformation.MapSize.TINY);
        Camera.create();
    }
    public static void process() {
        float delta = TimeUtilities.Frames.getDeltaTime();

        BatchRenderer.process(delta);
    }
    public static void update() {
        float delta = TimeUtilities.Frames.getDeltaTime();

        BatchRenderer.draw(delta);
    }
}
