package org.coloride.twoodee.Utilities;

import com.badlogic.gdx.Gdx;

public class TimeUtilities {
    public static class Frames {
        public static float getDeltaTime() {
            return Gdx.graphics.getDeltaTime();
        }
    }
}
