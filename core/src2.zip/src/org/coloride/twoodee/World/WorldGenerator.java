package org.coloride.twoodee.World;

import com.badlogic.gdx.math.Vector2;
import jdk.nashorn.internal.runtime.Debug;
import org.coloride.twoodee.World.Biomes.DebugBiome;

import java.util.Map;
import java.util.Vector;

public class WorldGenerator {
    public static void generateWorld() {
        Vector2 chunkPosition = new Vector2();
        MapInformation.MapSize mapSize = MapInformation.getLoadedMap().getMapSize();

        for (int cx = 0; cx < MapInformation.mapSizes.get(mapSize).x; cx++) {
            for (int cy = 0; cy < MapInformation.mapSizes.get(mapSize).y; cy++) {
                // For each chunk
                chunkPosition = new Vector2(cx,cy);
                System.out.println(cx + " - " + cy  + " generating...");

                Chunk chunk = new Chunk(chunkPosition, new DebugBiome());
                chunk.generate();

                MapInformation.getLoadedMap().getChunks().put(chunkPosition, chunk);
                //MapInformation.loadedChunks.put(chunkPosition, chunk);
            }
        }
    };
}
