package org.coloride.twoodee.World;

public class GreedyMeshing {
    public static void draw(float delta) {

    }
}
